import { useState } from "react";

const API_BASE = "http://localhost:5000";

function App() {
  const [messages, setMessages] = useState([
    { role: "ai", text: "Hi! I'm CheerChat 💙 — your mental health buddy. How are you feeling today?" },
  ]);
  const [input, setInput] = useState("");
  const [quote, setQuote] = useState(null);
  const [journal, setJournal] = useState("");

  const sendMessage = async () => {
    if (!input.trim()) return;
    const userMessage = { role: "user", text: input };
    setMessages([...messages, userMessage]);

    const res = await fetch(`${API_BASE}/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: input }),
    });
    const data = await res.json();
    const aiMessage = { role: "ai", text: data.reply };

    setMessages((prev) => [...prev, aiMessage]);
    setInput("");
  };

  const getQuote = async () => {
    const res = await fetch(`${API_BASE}/quotes`);
    const data = await res.json();
    setQuote(data.quote);
  };

  const saveJournal = async () => {
    await fetch(`${API_BASE}/journal`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: journal }),
    });
    alert("📝 Journal saved.");
    setJournal("");
  };

  return (
    <div style={{ padding: 20, fontFamily: "sans-serif", maxWidth: 600, margin: "auto" }}>
      <h1 style={{ color: "#4F8EF7", textAlign: "center" }}>💙 CheerChat</h1>
      <p style={{ textAlign: "center", fontStyle: "italic", color: "#777" }}>Your friendly mental health buddy</p>

      <div style={{ maxHeight: 300, overflowY: "auto", background: "#f5f5f5", padding: 10, margin: "20px 0", borderRadius: 10 }}>
        {messages.map((msg, i) => (
          <div key={i} style={{
            textAlign: msg.role === "user" ? "right" : "left",
            background: msg.role === "user" ? "#d6e8ff" : "#e0e0e0",
            padding: "8px 12px",
            borderRadius: 10,
            margin: "5px 0",
            maxWidth: "80%",
            marginLeft: msg.role === "user" ? "auto" : 0,
          }}>
            {msg.text}
          </div>
        ))}
      </div>

      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Type how you're feeling..."
        style={{ width: "100%", padding: 10, marginBottom: 10, borderRadius: 8, border: "1px solid #ccc" }}
      />
      <button onClick={sendMessage} style={{ background: "#4F8EF7", color: "#fff", padding: "10px 20px", border: "none", borderRadius: 8 }}>Send</button>

      <div style={{ marginTop: 20 }}>
        <button onClick={getQuote} style={{ marginRight: 10, background: "#FFD66B", padding: "8px 16px", border: "none", borderRadius: 8 }}>✨ Motivation</button>
        <button onClick={() => alert("Inhale... Hold... Exhale... 🧘")} style={{ background: "#7BDFF2", padding: "8px 16px", border: "none", borderRadius: 8 }}>🧘 Breathe</button>
      </div>

      <textarea
        value={journal}
        onChange={(e) => setJournal(e.target.value)}
        placeholder="Write your thoughts..."
        rows={4}
        style={{ width: "100%", marginTop: 10, padding: 10, borderRadius: 8, border: "1px solid #ccc" }}
      />
      <button onClick={saveJournal} style={{ background: "#4F8EF7", color: "#fff", padding: "10px 20px", border: "none", borderRadius: 8, marginTop: 5 }}>Save Journal</button>

      {quote && <p style={{ marginTop: 20, textAlign: "center", color: "#4F8EF7", fontStyle: "italic" }}>“{quote}”</p>}
    </div>
  );
}

export default App;
